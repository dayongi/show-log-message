# encoding: utf-8
"""
Author: tianxiaoyong_b00573@baosight.com
Datetime: 2019/6/1 15:05
File: test.py
Description: 
"""

import os
from pygtail import Pygtail
import io
from concurrent.futures import ThreadPoolExecutor
import sys

path = r"C:\Users\www13\Desktop\or\main\templates\test.txt"


def write():
    while True:
        s = input("请输入内容：")
        with open(path, 'a') as f:
            f.write(s + '\n')


# def read():
#     while True:
#         for line in Pygtail(path):
#             sys.stdout.write(line)


if __name__ == '__main__':
    thread = ThreadPoolExecutor(2)
    # thread.submit(read)

    thread.submit(write)
