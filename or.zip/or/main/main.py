import asyncio
import tornado.escape
import tornado.ioloop
import tornado.locks
import tornado.web
import os.path
import uuid
from pygtail import Pygtail
from concurrent.futures import ThreadPoolExecutor
from tornado.concurrent import run_on_executor
from tornado.options import define, options, parse_command_line
import requests
import time
executor = ThreadPoolExecutor(4)

define("port", default=8888, help="run on the given port", type=int)
define("debug", default=True, help="run in debug mode")


class MessageBuffer(object):
    def __init__(self):
        # cond is notified whenever the message cache is updated
        self.cond = tornado.locks.Condition()
        self.cache = []
        self.cache_size = 200

    def get_messages_since(self, cursor):
        results = []
        for msg in reversed(self.cache):
            if msg["id"] == cursor:
                break
            results.append(msg)
        results.reverse()
        return results

    def add_message(self, message):
        self.cache.append(message)
        if len(self.cache) > self.cache_size:
            self.cache = self.cache[-self.cache_size:]
        self.cond.notify_all()


global_message_buffer = MessageBuffer()


# def run():
#     path = r"C:\Users\www13\Desktop\or\main\templates\test.txt"
#     print("开始检测文件")
#     while True:
#         for message in Pygtail(filename=path, offset_file="main/templates/test.txt.offset"):
#             print(message)
#             message = {"id": str(uuid.uuid4()), "body": message}
#             global_message_buffer.add_message(message)
#             requests.get('http://127.0.0.1:8888/a/message/updates')


# def go():
#     thread_helper = ThreadPoolExecutor(4)
#     thread_helper.submit(run)


class MainHandler(tornado.web.RequestHandler):
    executor = ThreadPoolExecutor(1)

    def get(self):
        self.run()
        self.render("index.html", messages=global_message_buffer.cache)

    @run_on_executor
    def run(self):
        path = r"C:\Users\www13\Desktop\or\main\templates\test.txt"
        print(path)
        # while True:
        for message in Pygtail(filename=path, offset_file="main/templates/test.txt.offset"):
                print(message)
                message = {"id": str(uuid.uuid4()), "body": message}
                global_message_buffer.add_message(message)
                time.sleep(1)
                requests.get('http://127.0.0.1:8888/a/message/updates')


class MessageUpdatesHandler(tornado.web.RequestHandler):
    async def get(self):
        cursor = self.get_argument("cursor", None)
        messages = global_message_buffer.get_messages_since(cursor)
        print(messages)
        for m in messages:
            m['html'] = tornado.escape.to_unicode(
                self.render_string("message.html", message=m)
            )
        while not messages:
            self.wait_future = global_message_buffer.cond.wait()
            try:
                await self.wait_future
            except asyncio.CancelledError:
                return
            messages = global_message_buffer.get_messages_since(cursor)
        if self.request.connection.stream.closed():
            return
        self.write(dict(messages=messages))

    def on_connection_close(self):
        self.wait_future.cancel()


def main():
    parse_command_line()
    app = tornado.web.Application(
        [
            (r"/", MainHandler),
            (r"/a/message/updates", MessageUpdatesHandler),
        ],
        cookie_secret="__TODO:_GENERATE_YOUR_OWN_RANDOM_VALUE_HERE__",
        template_path=os.path.join(os.path.dirname(__file__), "templates"),
        static_path=os.path.join(os.path.dirname(__file__), "static"),
        xsrf_cookies=True,
        debug=options.debug,
    )
    app.listen(options.port)
    loop = tornado.ioloop.IOLoop.current()
    loop.start()


if __name__ == "__main__":
    main()
